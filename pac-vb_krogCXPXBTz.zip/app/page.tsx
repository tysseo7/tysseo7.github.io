"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, RotateCcw, Play, Pause, Volume2, VolumeX } from "lucide-react"

type Position = { x: number; y: number }
type Direction = "up" | "down" | "left" | "right" | null
type GhostState = "chase" | "scatter" | "vulnerable" | "returning"

interface Ghost {
  id: string
  position: Position
  direction: Direction
  color: string
  state: GhostState
  homeCorner: Position
}

const BOARD_WIDTH = 19
const BOARD_HEIGHT = 21
const CELL_SIZE = 16

export default function PacPiGame() {
  const [playerPos, setPlayerPos] = useState<Position>({ x: 9, y: 15 })
  const [direction, setDirection] = useState<Direction>(null)
  const [nextDirection, setNextDirection] = useState<Direction>(null)
  const [score, setScore] = useState(0)
  const [lives, setLives] = useState(3)
  const [gameRunning, setGameRunning] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [level, setLevel] = useState(1)
  const [powerMode, setPowerMode] = useState(false)
  const [powerModeTimer, setPowerModeTimer] = useState(0)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [mouthOpen, setMouthOpen] = useState(true)
  const audioRef = useRef<HTMLAudioElement>(null)

  // Classic Pac-Man maze layout (mirrored)
  const [board, setBoard] = useState(() => {
    const maze = [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 4, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 4, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1],
      [1, 2, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2, 2, 1],
      [1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 1, 0, 1, 2, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 2, 0, 0, 1, 0, 1, 0, 0, 2, 0, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1],
      [1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 1],
      [1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1],
      [1, 2, 2, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1],
      [1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ]
    return maze
  })

  const [ghosts, setGhosts] = useState<Ghost[]>([
    {
      id: "blinky",
      position: { x: 9, y: 9 },
      direction: "up",
      color: "red",
      state: "chase",
      homeCorner: { x: 17, y: 1 },
    },
    {
      id: "pinky",
      position: { x: 9, y: 10 },
      direction: "down",
      color: "pink",
      state: "scatter",
      homeCorner: { x: 1, y: 1 },
    },
    {
      id: "inky",
      position: { x: 8, y: 10 },
      direction: "up",
      color: "cyan",
      state: "scatter",
      homeCorner: { x: 17, y: 19 },
    },
    {
      id: "clyde",
      position: { x: 10, y: 10 },
      direction: "up",
      color: "orange",
      state: "scatter",
      homeCorner: { x: 1, y: 19 },
    },
  ])

  // Mouth animation
  useEffect(() => {
    if (gameRunning && direction) {
      const mouthInterval = setInterval(() => {
        setMouthOpen((prev) => !prev)
      }, 200)
      return () => clearInterval(mouthInterval)
    }
  }, [gameRunning, direction])

  // Handle directional button press
  const handleDirectionPress = useCallback(
    (newDirection: Direction) => {
      if (newDirection) {
        setNextDirection(newDirection)
      }

      if (!gameRunning && !gameOver) {
        setGameRunning(true)
      }
    },
    [gameRunning, gameOver],
  )

  const movePlayer = useCallback(() => {
    if (!gameRunning) return

    setPlayerPos((prev) => {
      // Check if we can turn in the buffered direction
      if (nextDirection) {
        let testX = prev.x
        let testY = prev.y

        switch (nextDirection) {
          case "up":
            testY = prev.y - 1
            break
          case "down":
            testY = prev.y + 1
            break
          case "left":
            testX = prev.x - 1
            break
          case "right":
            testX = prev.x + 1
            break
        }

        // Handle warp tunnel
        if (testX < 0) testX = BOARD_WIDTH - 1
        if (testX >= BOARD_WIDTH) testX = 0

        // Check if the buffered direction is valid (not a wall)
        if (board[testY] && board[testY][testX] !== 1) {
          // We can turn! Use the buffered direction
          setDirection(nextDirection)
          setNextDirection(null)
        }
      }

      // Now move in the current direction
      if (!direction) return prev

      let newX = prev.x
      let newY = prev.y

      switch (direction) {
        case "up":
          newY = prev.y - 1
          break
        case "down":
          newY = prev.y + 1
          break
        case "left":
          newX = prev.x - 1
          break
        case "right":
          newX = prev.x + 1
          break
      }

      // Warp tunnel logic
      if (newX < 0) newX = BOARD_WIDTH - 1
      if (newX >= BOARD_WIDTH) newX = 0

      // Check for wall collision
      if (board[newY] && board[newY][newX] === 1) {
        // Hit a wall, stop moving
        setDirection(null)
        return prev
      }

      // Check for π cookie
      if (board[newY] && board[newY][newX] === 2) {
        setBoard((prevBoard) => {
          const newBoard = [...prevBoard]
          newBoard[newY][newX] = 0
          return newBoard
        })
        setScore((prevScore) => prevScore + 10)
      }

      // Check for power cookie
      if (board[newY] && board[newY][newX] === 4) {
        setBoard((prevBoard) => {
          const newBoard = [...prevBoard]
          newBoard[newY][newX] = 0
          return newBoard
        })
        setScore((prevScore) => prevScore + 50)
        setPowerMode(true)
        setPowerModeTimer(10000) // 10 seconds
      }

      return { x: newX, y: newY }
    })
  }, [direction, nextDirection, gameRunning, board])

  const getGhostTarget = useCallback(
    (ghost: Ghost): Position => {
      switch (ghost.state) {
        case "chase":
          switch (ghost.id) {
            case "blinky":
              return playerPos // Direct chase
            case "pinky":
              // Target 4 spaces ahead of player
              let targetX = playerPos.x
              let targetY = playerPos.y
              switch (direction) {
                case "up":
                  targetY -= 4
                  break
                case "down":
                  targetY += 4
                  break
                case "left":
                  targetX -= 4
                  break
                case "right":
                  targetX += 4
                  break
              }
              return { x: targetX, y: targetY }
            case "inky":
              // Complex targeting based on Blinky and player
              const blinky = ghosts.find((g) => g.id === "blinky")
              if (blinky) {
                return {
                  x: playerPos.x + (playerPos.x - blinky.position.x),
                  y: playerPos.y + (playerPos.y - blinky.position.y),
                }
              }
              return playerPos
            case "clyde":
              // Chase if far, scatter if close
              const distance = Math.abs(ghost.position.x - playerPos.x) + Math.abs(ghost.position.y - playerPos.y)
              return distance > 8 ? playerPos : ghost.homeCorner
            default:
              return playerPos
          }
        case "scatter":
          return ghost.homeCorner
        case "vulnerable":
          // Run away from player
          return {
            x: ghost.position.x + (ghost.position.x - playerPos.x),
            y: ghost.position.y + (ghost.position.y - playerPos.y),
          }
        case "returning":
          return { x: 9, y: 9 } // Ghost house
        default:
          return ghost.homeCorner
      }
    },
    [playerPos, direction, ghosts],
  )

  const moveGhosts = useCallback(() => {
    if (!gameRunning) return

    setGhosts((prevGhosts) =>
      prevGhosts.map((ghost) => {
        const target = getGhostTarget(ghost)
        const possibleMoves = ["up", "down", "left", "right"].filter((dir) => {
          let newX = ghost.position.x
          let newY = ghost.position.y

          switch (dir) {
            case "up":
              newY--
              break
            case "down":
              newY++
              break
            case "left":
              newX--
              break
            case "right":
              newX++
              break
          }

          // Warp tunnel
          if (newX < 0) newX = BOARD_WIDTH - 1
          if (newX >= BOARD_WIDTH) newX = 0

          return board[newY] && board[newY][newX] !== 1
        })

        // Choose best direction toward target
        let bestDirection = ghost.direction || "up"
        let bestDistance = Number.POSITIVE_INFINITY

        possibleMoves.forEach((dir) => {
          let newX = ghost.position.x
          let newY = ghost.position.y

          switch (dir) {
            case "up":
              newY--
              break
            case "down":
              newY++
              break
            case "left":
              newX--
              break
            case "right":
              newX++
              break
          }

          if (newX < 0) newX = BOARD_WIDTH - 1
          if (newX >= BOARD_WIDTH) newX = 0

          const distance = Math.abs(newX - target.x) + Math.abs(newY - target.y)
          if (distance < bestDistance) {
            bestDistance = distance
            bestDirection = dir as Direction
          }
        })

        let newX = ghost.position.x
        let newY = ghost.position.y

        switch (bestDirection) {
          case "up":
            newY--
            break
          case "down":
            newY++
            break
          case "left":
            newX--
            break
          case "right":
            newX++
            break
        }

        if (newX < 0) newX = BOARD_WIDTH - 1
        if (newX >= BOARD_WIDTH) newX = 0

        return {
          ...ghost,
          position: { x: newX, y: newY },
          direction: bestDirection,
          state: powerMode ? "vulnerable" : ghost.state === "vulnerable" ? "chase" : ghost.state,
        }
      }),
    )
  }, [gameRunning, board, getGhostTarget, powerMode])

  // Power mode timer
  useEffect(() => {
    if (powerMode && powerModeTimer > 0) {
      const timer = setTimeout(() => {
        setPowerModeTimer((prev) => prev - 100)
      }, 100)
      return () => clearTimeout(timer)
    } else if (powerModeTimer <= 0) {
      setPowerMode(false)
    }
  }, [powerMode, powerModeTimer])

  // Check for collisions with ghosts
  useEffect(() => {
    ghosts.forEach((ghost) => {
      if (ghost.position.x === playerPos.x && ghost.position.y === playerPos.y) {
        if (powerMode && ghost.state === "vulnerable") {
          // Eat ghost
          setScore((prev) => prev + 200)
          setGhosts((prev) => prev.map((g) => (g.id === ghost.id ? { ...g, state: "returning" } : g)))
        } else if (ghost.state !== "returning") {
          // Player caught
          setLives((prev) => prev - 1)
          setPlayerPos({ x: 9, y: 15 })
          setDirection(null)
          setNextDirection(null)
          if (lives <= 1) {
            setGameOver(true)
            setGameRunning(false)
          }
        }
      }
    })
  }, [playerPos, ghosts, powerMode, lives])

  // Check for win condition
  useEffect(() => {
    const piCookiesLeft = board.flat().filter((cell) => cell === 2).length
    if (piCookiesLeft === 0 && gameRunning) {
      setLevel((prev) => prev + 1)
      setGameRunning(false)
      // Reset board for next level
      setTimeout(() => {
        resetGame(false)
        setGameRunning(true)
      }, 2000)
    }
  }, [board, gameRunning])

  // Game loop
  useEffect(() => {
    if (!gameRunning) return

    const gameInterval = setInterval(
      () => {
        movePlayer()
        moveGhosts()
      },
      200 - level * 10,
    ) // Speed increases with level

    return () => clearInterval(gameInterval)
  }, [movePlayer, moveGhosts, gameRunning, level])

  const resetGame = (fullReset = true) => {
    setPlayerPos({ x: 9, y: 15 })
    setDirection(null)
    setNextDirection(null)
    setGameRunning(false)
    setGameOver(false)
    setPowerMode(false)
    setPowerModeTimer(0)
    setMouthOpen(true)

    if (fullReset) {
      setScore(0)
      setLives(3)
      setLevel(1)
    }

    setGhosts([
      {
        id: "blinky",
        position: { x: 9, y: 9 },
        direction: "up",
        color: "red",
        state: "chase",
        homeCorner: { x: 17, y: 1 },
      },
      {
        id: "pinky",
        position: { x: 9, y: 10 },
        direction: "down",
        color: "pink",
        state: "scatter",
        homeCorner: { x: 1, y: 1 },
      },
      {
        id: "inky",
        position: { x: 8, y: 10 },
        direction: "up",
        color: "cyan",
        state: "scatter",
        homeCorner: { x: 17, y: 19 },
      },
      {
        id: "clyde",
        position: { x: 10, y: 10 },
        direction: "up",
        color: "orange",
        state: "scatter",
        homeCorner: { x: 1, y: 19 },
      },
    ])

    // Reset board
    const maze = [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 4, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 4, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1],
      [1, 2, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2, 2, 1],
      [1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 2, 1, 0, 1, 0, 1, 0, 1, 2, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 2, 0, 0, 1, 0, 1, 0, 0, 2, 0, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1],
      [1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 1],
      [1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1],
      [1, 2, 2, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1],
      [1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1],
      [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    ]
    setBoard(maze)
  }

  const toggleGame = () => {
    if (gameOver) {
      resetGame()
    } else {
      setGameRunning(!gameRunning)
    }
  }

  const getGhostColor = (ghost: Ghost) => {
    if (ghost.state === "vulnerable") {
      return powerModeTimer > 2000 ? "text-blue-500" : "text-white animate-pulse" // Flash when power mode ending
    }
    switch (ghost.color) {
      case "red":
        return "text-red-500"
      case "pink":
        return "text-pink-500"
      case "cyan":
        return "text-cyan-400"
      case "orange":
        return "text-orange-500"
      default:
        return "text-blue-500"
    }
  }

  const getPacManEmoji = () => {
    if (!direction) return "🟡"

    if (mouthOpen) {
      switch (direction) {
        case "up":
          return "🔺"
        case "down":
          return "🔻"
        case "left":
          return "◀️"
        case "right":
          return "▶️"
        default:
          return "🟡"
      }
    } else {
      return "🟡"
    }
  }

  const renderCell = (cell: number, x: number, y: number) => {
    const isPlayer = playerPos.x === x && playerPos.y === y
    const ghost = ghosts.find((g) => g.position.x === x && g.position.y === y)

    if (isPlayer) {
      return <div className="text-yellow-400 font-bold text-lg">{getPacManEmoji()}</div>
    }
    if (ghost) {
      return <div className={`font-bold text-lg ${getGhostColor(ghost)}`}>👻</div>
    }

    switch (cell) {
      case 1: // Wall
        return <div className="bg-blue-600 w-full h-full"></div>
      case 2: // Pi cookie
        return <div className="text-yellow-300 font-bold text-xs">π</div>
      case 4: // Power cookie
        return <div className="text-yellow-400 font-bold text-lg animate-pulse">●</div>
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center p-4">
      <Card className="w-full max-w-sm bg-gray-900 border-gray-700">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-xl font-bold text-yellow-400">PAC-Pi</CardTitle>
          <div className="flex justify-between items-center text-xs">
            <span>Score: {score}</span>
            <span>Level: {level}</span>
            <span>Lives: {"🟡".repeat(lives)}</span>
          </div>
          {powerMode && (
            <div className="text-center text-blue-400 text-xs animate-pulse">
              POWER MODE: {Math.ceil(powerModeTimer / 1000)}s
            </div>
          )}
          {nextDirection && (
            <div className="text-center text-gray-400 text-xs">Next: {nextDirection.toUpperCase()}</div>
          )}
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Game Board */}
          <div
            className="grid gap-0 mx-auto border-2 border-blue-500 bg-black p-1"
            style={{
              gridTemplateColumns: `repeat(${BOARD_WIDTH}, ${CELL_SIZE}px)`,
              width: `${BOARD_WIDTH * CELL_SIZE + 8}px`,
            }}
          >
            {board.map((row, y) =>
              row.map((cell, x) => (
                <div
                  key={`${x}-${y}`}
                  className="flex items-center justify-center"
                  style={{ width: CELL_SIZE, height: CELL_SIZE }}
                >
                  {renderCell(cell, x, y)}
                </div>
              )),
            )}
          </div>

          {/* Game Status */}
          {gameOver && (
            <div className="text-center text-red-400 font-bold text-sm">GAME OVER! Final Score: {score}</div>
          )}

          {/* Control Buttons */}
          <div className="flex justify-center gap-2 mb-4">
            <Button
              onClick={toggleGame}
              variant="outline"
              size="sm"
              className="bg-gray-800 border-gray-600 hover:bg-gray-700"
            >
              {gameOver ? (
                <RotateCcw className="w-4 h-4" />
              ) : gameRunning ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </Button>
            <Button
              onClick={() => resetGame()}
              variant="outline"
              size="sm"
              className="bg-gray-800 border-gray-600 hover:bg-gray-700"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
            <Button
              onClick={() => setSoundEnabled(!soundEnabled)}
              variant="outline"
              size="sm"
              className="bg-gray-800 border-gray-600 hover:bg-gray-700"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </Button>
          </div>

          {/* 4-Directional Control Keys */}
          <div className="grid grid-cols-3 gap-2 max-w-48 mx-auto">
            <div></div>
            <Button
              onTouchStart={() => handleDirectionPress("up")}
              onClick={() => handleDirectionPress("up")}
              variant="outline"
              size="lg"
              className={`bg-gray-800 border-gray-600 hover:bg-gray-700 active:bg-gray-600 ${
                nextDirection === "up" ? "bg-yellow-600 border-yellow-500" : ""
              }`}
            >
              <ArrowUp className="w-6 h-6" />
            </Button>
            <div></div>

            <Button
              onTouchStart={() => handleDirectionPress("left")}
              onClick={() => handleDirectionPress("left")}
              variant="outline"
              size="lg"
              className={`bg-gray-800 border-gray-600 hover:bg-gray-700 active:bg-gray-600 ${
                nextDirection === "left" ? "bg-yellow-600 border-yellow-500" : ""
              }`}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div></div>
            <Button
              onTouchStart={() => handleDirectionPress("right")}
              onClick={() => handleDirectionPress("right")}
              variant="outline"
              size="lg"
              className={`bg-gray-800 border-gray-600 hover:bg-gray-700 active:bg-gray-600 ${
                nextDirection === "right" ? "bg-yellow-600 border-yellow-500" : ""
              }`}
            >
              <ArrowRight className="w-6 h-6" />
            </Button>

            <div></div>
            <Button
              onTouchStart={() => handleDirectionPress("down")}
              onClick={() => handleDirectionPress("down")}
              variant="outline"
              size="lg"
              className={`bg-gray-800 border-gray-600 hover:bg-gray-700 active:bg-gray-600 ${
                nextDirection === "down" ? "bg-yellow-600 border-yellow-500" : ""
              }`}
            >
              <ArrowDown className="w-6 h-6" />
            </Button>
            <div></div>
          </div>

          {/* Instructions */}
          <div className="text-xs text-gray-400 text-center space-y-1">
            <p>🟡 = PAC-Pi | π = Pi Cookies | ● = Power Cookies</p>
            <p>👻 = Ghosts (Red: Blinky, Pink: Pinky, Cyan: Inky, Orange: Clyde)</p>
            <p>Use directional buttons to queue movement</p>
            <p>PAC-Pi turns when reaching a corner where turning is possible</p>
          </div>
        </CardContent>
      </Card>

      {/* Background audio */}
      <audio ref={audioRef} loop muted={!soundEnabled}>
        <source src="/placeholder-audio.mp3" type="audio/mpeg" />
      </audio>
    </div>
  )
}
